#include "d3/patches.hpp"

#include "d3/_util.hpp"
#include "d3/resolution_util.hpp"
#include "lib/armv8/instructions.hpp"
#include "lib/armv8/register.hpp"
#include "lib/patch/random_access_patcher.hpp"
#include "program/build_stamp.hpp"
#include "program/config.hpp"

#include <array>
#include <cstddef>
#include <cstdint>

namespace d3 {

    const char *const    g_szHackVerWatermark = d3::build_stamp::kVersionLine;
    const char *const    g_szHackVerAutosave  = d3::build_stamp::kAutosaveString;
    constinit const char g_szHackVerStart[]   = CRLF D3HACK_FULLVER CRLF CRLF CRLF;

    constinit const char      g_szTraceStat[]         = "sd:/config/d3hack-nx/debug.txt";
    constinit const char      g_szVariableResString[] = "%4dp Output (Variable: %4dp)";
    constinit const Signature g_tSignature {.szName = "   " D3HACK_VER CRLF D3HACK_WEB CRLF " ", .szComment = "Diablo III v", .nMonth = 2, .nDay = 7, .nYear = 6};
    const RGBAColor           g_rgbaText       = crgbaUIGold;
    const RGBAColor           g_rgbaDropShadow = crgbaWatermarkShadow;

    namespace patch = exl::patch;
    namespace reg   = exl::armv8::reg;
    namespace ins   = exl::armv8::inst;

    using dword                                       = std::array<std::byte, 0x4>;
    static const dword k_infinite_mp_restore_call     = make_bytes(0x41, 0xFF, 0xFF, 0x97);  // BL ActorCommonData::ResourceAttributeSetFloat(int,float,int)
    static const dword k_dynamic_seasonal_restore_tbz = make_bytes(0xA8, 0x00, 0x90, 0x36);  // TBZ W8,#0x12,loc_4CACCC (2.7.6 @ 0x4CACB8)

    static bool     g_dynamic_seasonal_patch_applied = false;
    static uint64_t g_dynamic_seasonal_generation    = 0;
    static auto     PatchTable(const char *name) -> uintptr_t;

    static void SetDynamicSeasonalPatchArmed(bool armed, const char *reason) {
        if (!global_config.seasons.active) {
            armed = false;
        }
        if (g_dynamic_seasonal_patch_applied == armed) {
            return;
        }

        auto jest = patch::RandomAccessPatcher();
        if (armed) {
            jest.Patch<ins::Nop>(PatchTable("patch_dynamic_seasonal_10_nop"));
        } else {
            jest.Patch<dword>(PatchTable("patch_dynamic_seasonal_10_nop"), k_dynamic_seasonal_restore_tbz);
        }

        g_dynamic_seasonal_patch_applied = armed;
        ++g_dynamic_seasonal_generation;
        PRINT(
            "[seasonal_gate] apply=%d gen=%llu reason=%s",
            armed ? 1 : 0,
            static_cast<unsigned long long>(g_dynamic_seasonal_generation),
            reason ? reason : "<none>"
        )
    }

    static auto PatchTable(const char *name) -> uintptr_t {
        return GameOffsetFromTable(name) - exl::util::modules::GetTargetStart();
    }

    static void MakeAdrlPatch(const uintptr_t mainAddr, uintptr_t adrpTarget, const exl::armv8::reg::Register registerTarget) {
        auto            jest       = patch::RandomAccessPatcher();
        uintptr_t const adrpOffset = mainAddr;
        auto            diff       = ins::Adrp::GetDifference(GameOffset(adrpOffset), adrpTarget);
        jest.Patch<ins::Adrp>(adrpOffset, registerTarget, diff.m_Page);
        jest.Patch<ins::AddImmediate>(adrpOffset + 4, registerTarget, registerTarget, diff.m_Offset);
    }

    /* String swap and formatting for BuildLockerDrawWatermark() */
    void PatchBuildlocker() {
        if (!(global_config.overlays.active && global_config.overlays.buildlocker_watermark))
            return;
        auto jest = patch::RandomAccessPatcher();
        /* Spoof the existence of a build signature so we can use the debug watermark (tSignature) */
        jest.Patch<ins::Nop>(PatchTable("patch_buildlocker_01_nop"));
        jest.Patch<ins::Movz>(PatchTable("patch_buildlocker_02_movz"), reg::W20, (8 + GLOBALSNO_FONT_SCRIPT));
        MakeAdrlPatch(PatchTable("patch_buildlocker_03_adrl"), reinterpret_cast<uintptr_t>(&g_tSignature), reg::X2);
        MakeAdrlPatch(PatchTable("patch_buildlocker_04_adrl"), reinterpret_cast<uintptr_t>(&crgbaTan), reg::X19);
        MakeAdrlPatch(PatchTable("patch_buildlocker_05_adrl"), reinterpret_cast<uintptr_t>(g_szHackVerWatermark), reg::X1);
        auto *szBuildLockerFormat = reinterpret_cast<std::array<char, 21> *>(jest.RwFromAddr(PatchTable("data_build_locker_format_rw")));
        *szBuildLockerFormat      = std::to_array("%s%s%d.%d.%d\0\0\0\0\0\0\0\0");
        jest.Patch<ins::Movz>(PatchTable("patch_buildlocker_06_movz"), reg::W21, 0x13);  // RENDERLAYER_UI_OVERLAY

        /* 0x10CC - lower right */

        /* 0x1114 - upper left */
        //      0x106C 09 D0 35 1E                   FMOV            S9, #-15.0
        //      0x10D4 0A D0 25 1E                   FMOV            S10, #15.0
        //      0x10D8 21 28 2A 1E                   FADD            S1, S1, S10 <- Y-axis from top
        //      0x10FC 00 28 29 1E                   FADD            S0, S0, S9  <- X-axis from left
        jest.Patch<dword>(PatchTable("patch_buildlocker_07_bytes"), make_bytes(0x00, 0x28, 0x2A, 0x1E));  // S0, +15.0 (S10) instead of -15.0

        /* 0x1160 - Lower left */
        //      0x1120 21 38 22 1E                   FSUB            S1, S1, S2
        //      0x1128 00 28 29 1E                   FADD            S0, S0, S9
        //      0x1150 21 28 29 1E                   FADD            S1, S1, S9
        jest.Patch<dword>(PatchTable("patch_buildlocker_08_bytes"), make_bytes(0x00, 0x28, 0x2A, 0x1E));  // S0, +15.0 (S10) instead of -15.0

        /* 0x11AC - upper right */

        /* 0x1224 - center screen */
        jest.Patch<ins::Nop>(PatchTable("patch_buildlocker_09_nop"));

        /* 0x12F8 - primary, lower middle */
        //      0x11C0 0A 10 2C 1E                   FMOV            S10, #0.5 <- center X axis on screen
        // jest.Patch<dword>(PatchTable("patch_buildlocker_10_bytes"), make_bytes(0x0A, 0x10, 0x2E, 0x1E));  // #1.0, aka shift right
    }

    /* String swap and formatting for APP_DRAW_VARIABLE_RES_DEBUG_BIT */
    void PatchVarResLabel() {
        auto jest = patch::RandomAccessPatcher();
        jest.Patch<ins::Movz>(PatchTable("patch_var_res_label_01_movz"), reg::W0, (8 + GLOBALSNO_FONT_EXOCETLIGHT));
        // 3CC78    movz x8, #0x42c8, lsl #16   --> 100.0f
        jest.Patch<ins::Movz>(PatchTable("patch_var_res_label_02_movz"), reg::X8, 0x4288, ins::ShiftValue_16);  // X-axis: 68.0f
        // 3CC7C    movk x8, #0x4316, lsl #48   --> 150.0f
        jest.Patch<ins::Movk>(PatchTable("patch_var_res_label_03_movk"), reg::X8, 0x4080, ins::ShiftValue_48);  // Y-axis: 4.0f

        // MakeAdrlPatch(PatchTable("patch_var_res_label_04_adrl"), reinterpret_cast<uintptr_t>(&c_szVariableResString), reg::X1);
        // AppDrawFlagSet(APP_DRAW_VARIABLE_RES_DEBUG_BIT, 1);     // Must be run each frame in another hook
    }

    void PatchGraphicsPersistentHeapEarly() {
        auto jest = patch::RandomAccessPatcher();
        // SigmaMemoryInit (sSigmaMemoryInit, 0xA36A50): gptGraphicsPersistentMemoryHeap size.
        // 0xA36B34: MOV reg::W19, #0x17400000
        u32 gfxPersistentHeapSize = 0x17400000u;

        [[maybe_unused]] constexpr u32 MB32 = 0x02000000u;
        [[maybe_unused]] constexpr u32 MB64 = 0x04000000u;

        // Bump graphics persistent heap (XRemoteHeap) to reduce alloc failures.
        if (g_ptDevMemMode != nullptr && *g_ptDevMemMode != 0u) {
            gfxPersistentHeapSize += 0x40000000u;  // extra 1GB if extra RAM detected
        } else {
            gfxPersistentHeapSize += MB64;         // 64MB allows 1440p, stable HOS >=20.x operation on hardware
        }

        jest.Patch<ins::Movz>(0xA36B34, reg::W19, (gfxPersistentHeapSize >> 16), ins::ShiftValue_16);
        PRINT_EXPR("Patched to: %08X", gfxPersistentHeapSize)
    }

    /* String swap and formatting for APP_DRAW_FPS_BIT */
    void PatchReleaseFPSLabel() {
        auto jest = patch::RandomAccessPatcher();
        jest.Patch<ins::Movz>(PatchTable("patch_release_fps_label_01_movz"), reg::W0, (8 + GLOBALSNO_FONT_EXOCETLIGHT));
        auto *szReleaseFPSFormat = reinterpret_cast<std::array<char, 10> *>(jest.RwFromAddr(PatchTable("data_release_fps_format_rw")));
        auto *nReleaseFPSPosX    = reinterpret_cast<float *>(jest.RoFromAddr(PatchTable("data_release_fps_pos_x_ro")));
        auto *nReleaseFPSPosY    = reinterpret_cast<float *>(jest.RoFromAddr(PatchTable("data_release_fps_pos_y_ro")));
        *szReleaseFPSFormat      = std::to_array("FPS: %.0f");  // :.ascii "%3.1f FPS"
        *nReleaseFPSPosX         = -77.7;                       // nReleaseFPSPosX:.float -180.0
        *nReleaseFPSPosY         = 500.0;                       // nReleaseFPSPosY:.float 290.0

        /* Skip the frame timer check/color setter (avoid flashing text colors) */
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_02_nop"));
        MakeAdrlPatch(PatchTable("patch_release_fps_label_03_adrl"), reinterpret_cast<uintptr_t>(&crgbaWhite), reg::X8);

        /* Skip rendering all extra FPS data labels */
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_04_nop"));
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_05_nop"));
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_06_nop"));
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_07_nop"));
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_08_nop"));
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_09_nop"));
        jest.Patch<ins::Nop>(PatchTable("patch_release_fps_label_10_nop"));

        // AppDrawFlagSet(APP_DRAW_FPS_BIT, 1);  // Must be run each frame in another hook
    }

    void PatchDDMLabels() {
        auto jest = patch::RandomAccessPatcher();
        /* String swap and formatting for DDM_FPS_QA */
        jest.Patch<ins::Movz>(PatchTable("patch_ddm_labels_01_movz"), reg::W0, (8 + GLOBALSNO_FONT_SCRIPT));
        MakeAdrlPatch(PatchTable("patch_ddm_labels_02_adrl"), reinterpret_cast<uintptr_t>(g_szHackVerWatermark), reg::X1);
        MakeAdrlPatch(PatchTable("patch_ddm_labels_03_adrl"), reinterpret_cast<uintptr_t>(&g_rgbaText), reg::X3);
        MakeAdrlPatch(PatchTable("patch_ddm_labels_04_adrl"), reinterpret_cast<uintptr_t>(&g_rgbaDropShadow), reg::X4);
        jest.Patch<ins::Movz>(PatchTable("patch_ddm_labels_05_movz"), reg::W7, 0x13);  // RENDERLAYER_UI_OVERLAY

        /* String swap and formatting for DDM_FPS_SIMPLE */
        jest.Patch<ins::Movz>(PatchTable("patch_ddm_labels_06_movz"), reg::W0, (8 + GLOBALSNO_FONT_SCRIPT));
        MakeAdrlPatch(PatchTable("patch_ddm_labels_07_adrl"), reinterpret_cast<uintptr_t>(g_szHackVerWatermark), reg::X23);
        MakeAdrlPatch(PatchTable("patch_ddm_labels_08_adrl"), reinterpret_cast<uintptr_t>(&g_rgbaText), reg::X3);
        MakeAdrlPatch(PatchTable("patch_ddm_labels_09_adrl"), reinterpret_cast<uintptr_t>(&g_rgbaDropShadow), reg::X4);
        jest.Patch<ins::Movz>(PatchTable("patch_ddm_labels_10_movz"), reg::W7, 0x13);  // RENDERLAYER_UI_OVERLAY
    }

    void PatchResolutionTargets() {
        auto jest = patch::RandomAccessPatcher();
        /* FontDefinition::GetPointSizeData (0x276A60/0x276A6C). */
        /* 0x276A60: MOV reg::W9, #8   | 0x276A6C: MOV reg::W8, #0x10 */
        jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_08_movz"), reg::W9, 32);
        jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_09_movz"), reg::W8, 32);

        // ShellInitialize (0x6678B8): BL nn::oe::GetOperationMode
        // ShellEventLoop (0x667AE8): BL nn::oe::GetOperationMode
        // jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_10_movz"), reg::W0, 0);  // 0 = "Docked"
        // jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_11_movz"), reg::W0, 0);  // 0 = "Docked"
        // ShellInitialize (0x6678C8): BL nn::oe::GetPerformanceMode
        // ShellEventLoop (0x667B04): BL nn::oe::GetPerformanceMode
        // jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_12_movz"), reg::W0, 1);  // 1 = "Boost"
        // jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_13_movz"), reg::W0, 1);  // 1 = "Boost"
        if (!(global_config.resolution_hack.active))
            return;

        /* ►Always run perf-mode change handler on perf notify (skip v8 == gePerformanceMode check). */
        // 0x667B10: B.EQ def_667A20
        // jest.Patch<ins::Nop>(0x667B10);  // always fall through to re-init UI

        auto      resolution = global_config.resolution_hack;
        const u32 max_target = MaxResolutionHackOutputTarget();
        if (resolution.target_resolution > max_target) {
            resolution.SetTargetRes(max_target);
        }
        const u32 outW      = resolution.OutputWidthPx();
        const u32 outH      = resolution.OutputHeightPx();
        const u32 handheldH = resolution.OutputHandheldHeightPx();
        const u32 fallbackW = handheldH != 0 ? resolution.WidthForHeight(handheldH) : 1280u;
        const u32 fallbackH = handheldH != 0 ? handheldH : 720u;
        // const u32 clampW = global_config.resolution_hack.ClampTextureWidthPx();
        // const u32 clampH = global_config.resolution_hack.ClampTextureHeightPx();

        // NX64NVNHeap::EarlyInit (0x0E7770): uMaxSize/Preallocate size.
        // 0x0E7770: MOV reg::W19, #0x49C00000
        // NX64NVNHeap::EarlyInit (0x0E77A0): largest pool max_alloc.
        // 0x0E77A0: MOV reg::W3, #0x8000000
        // Increase heap headroom + largest pool max_alloc for >1280p output.
        if (outH > 1280) {
            u32 heapSize = 0x59C00000;  // +0x10000000 (256 MB)
            u32 maxAlloc = 0x10000000;  // +0x08000000 (128 MB)
            if (outH >= 1800) {
                heapSize = 0x69C00000;  // +0x20000000 (512 MB)
                maxAlloc = 0x20000000;  // +0x18000000 (384 MB)
            }
            jest.Patch<ins::Movz>(0x0E7770, reg::W19, (heapSize >> 16), ins::ShiftValue_16);
            jest.Patch<ins::Movz>(0x0E77A0, reg::W3, (maxAlloc >> 16), ins::ShiftValue_16);
        }

        // Display mode pair (full). GFXNX64NVN::Init (0x0E7850).
        // 0x0E7858: MOV reg::X8, #1600
        // 0x0E7860: MOVK reg::X8, #900, LSL#32
        jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_01_movz"), reg::X8, outW);
        jest.Patch<ins::Movk>(PatchTable("patch_resolution_targets_02_movk"), reg::X8, outH, ins::ShiftValue_32);

        // Fallback/base scale mode (same block).
        // 0x0E785C: MOV reg::X9, #1280
        // 0x0E7864: MOVK reg::X9, #720, LSL#32
        jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_03_movz"), reg::X9, fallbackW);
        jest.Patch<ins::Movk>(PatchTable("patch_resolution_targets_04_movk"), reg::X9, fallbackH, ins::ShiftValue_32);

        // if (global_config.resolution_hack.min_res_scale >= 100.0f) {
        // Too late to patch cdecl defaults at this point, and prefer the hook
        //     /* VariableResRWindowData->flMinPercent = 0.70f - 0x03CBBC: MOVK reg::X9, #0x3F33, LSL#48 (CGameVariableResInitializeForRWindow) */
        //     jest.Patch<ins::Movk>(PatchTable("patch_resolution_targets_05_movk"), reg::X9, 0x3F80, ins::ShiftValue_48);  // 100% (1.0f) minimum resolution scale
        // }

        /* VariableResRWindowData->flMaxPercent = 1.00f - 0x03CBCC: MOV reg::W8, #0x3F800000 */
        // jest.Patch<ins::Movz>(PatchTable("patch_resolution_targets_06_movz"), reg::W8, 0x3FA0, ins::ShiftValue_16);  // 125% (1.25f) maximum resolution scale (>1.0f breaks rendering)

        /* VariableResRWindowData->flPercentIncr = 0.05f - 0x03CBD4: MOVK reg::X9, #0x3D4C, LSL#48 */
        // jest.Patch<ins::Movk>(PatchTable("patch_resolution_targets_07_movk"), reg::X9, 0x3CF5, ins::ShiftValue_48);  // 3% (0.03f) resolution adjust percentage
    }

    void PatchDynamicSeasonal() {
        if (!global_config.seasons.active) {
            SetDynamicSeasonalPatchArmed(false, "config_inactive");
            return;
        }

        PRINT("Setting active Season to %d", global_config.seasons.current_season)
        XVarUint32_Set(&g_varSeasonNum, global_config.seasons.current_season, 3u);
        XVarUint32_Set(&g_varSeasonState, 1, 3u);

        auto jest = patch::RandomAccessPatcher();
        jest.Patch<ins::Movz>(PatchTable("patch_dynamic_seasonal_03_movz"), reg::W1, 1);  // always true for UIHeroCreate::Console::bSeasonConfirmedAvailable() (skip B.ne and always confirm)
        jest.Patch<ins::Movz>(PatchTable("patch_dynamic_seasonal_04_movz"), reg::W0, 1);  // always true for Console::Online::IsSeasonsInitialized()

        // Update season_created uses at runtime (UIOnlineActions::SetGameParamsForHero).
        jest.Patch<ins::Movz>(PatchTable("patch_dynamic_seasonal_05_movz"), reg::W21, global_config.seasons.current_season);  // season_created = ...
        // Ignore mismatched hero season in UIHeroSelect (skip Rebirth/season prompt for old seasons).
        // jest.Patch<ins::Nop>(PatchTable("patch_dynamic_seasonal_06_nop"));  // B.ne loc_358C74
        // Hide "Create Seasonal Hero" main menu option (item 9) when forcing season current_season.
        // ItemShouldBeVisible(case 9) calls IsSeasonsInitialized; forcing reg::W0=0 makes it return false.
        // jest.Patch<ins::Movz>(PatchTable("patch_dynamic_seasonal_07_movz"), reg::W0, 0);
        /* Always return error_none for Console::UIOnlineActions::ValidateHeroForPartyMember (skip function body). */
        // 0x1BF5F0: SUB SP, SP, #0x100
        jest.Patch<ins::Movz>(PatchTable("patch_dynamic_seasonal_08_movz"), reg::W0, 0);  // error_none
        // 0x1BF5F4: STR X23, [SP,#0xF0+var_30]
        jest.Patch<ins::Ret>(PatchTable("patch_dynamic_seasonal_09_ret"));

        // Runtime-spawn gate defaults to OFF until the next GameCommonData::Initialize call.
        SetDynamicSeasonalPatchArmed(false, "season_bootstrap");
    }

    void UpdateDynamicSeasonalForSpawn(const GameParams *tParams) {
        if (!global_config.seasons.active) {
            SetDynamicSeasonalPatchArmed(false, "seasons_inactive");
            return;
        }

        constexpr uint32 kSeasonalCreationFlag = (1u << 18);

        const bool params_valid    = (tParams != nullptr);
        const bool params_seasonal = params_valid && ((tParams->dwCreationFlags & kSeasonalCreationFlag) != 0u);
        const bool spawn_seasonal  = params_valid && params_seasonal;

        PRINT(
            "[seasonal_gate] eval conn=%x flags=0x%x params_valid=%d params=%d",
            params_valid ? tParams->idGameConnection : static_cast<uint32>(0xFFFFFFFFu),
            params_valid ? tParams->dwCreationFlags : 0u,
            params_valid ? 1 : 0,
            params_seasonal ? 1 : 0
        )

        SetDynamicSeasonalPatchArmed(spawn_seasonal, spawn_seasonal ? "spawn_seasonal" : "spawn_nonseasonal");
    }

    void PatchDynamicEvents() {
        if (!global_config.events.active)
            return;

        constexpr s64 kBuffStartFallback = 1;
        constexpr s64 kBuffEndFallback   = 0x7FFFFFFFFFFFFFFFLL;

        auto *buff_start = *reinterpret_cast<s64 **>(GameOffsetFromTable("event_buff_start"));
        auto *buff_end   = *reinterpret_cast<s64 **>(GameOffsetFromTable("event_buff_end"));
        if ((buff_start != nullptr) && (buff_end != nullptr) && ((*buff_start == 0) || (*buff_end == 0) || *buff_end <= *buff_start)) {
            *buff_start = kBuffStartFallback;
            *buff_end   = kBuffEndFallback;
        }

        if (auto *egg_flag = *reinterpret_cast<u32 **>(GameOffsetFromTable("event_egg_flag")))
            *egg_flag = global_config.events.EasterEggWorldEnabled ? 1u : 0u;

        if (auto *igr = *reinterpret_cast<uintptr_t **>(GameOffsetFromTable("event_igr")))
            XVarBool_Set(igr, global_config.events.IgrEnabled, 3u);
        if (auto *ann = *reinterpret_cast<uintptr_t **>(GameOffsetFromTable("event_ann")))
            XVarBool_Set(ann, global_config.events.AnniversaryEnabled, 3u);
        if (auto *egg_xvar = *reinterpret_cast<uintptr_t **>(GameOffsetFromTable("event_egg_xvar")))
            XVarBool_Set(egg_xvar, global_config.events.EasterEggWorldEnabled, 3u);
        if (auto *event_enabled = *reinterpret_cast<uintptr_t **>(GameOffsetFromTable("event_enabled")))
            XVarBool_Set(event_enabled, true, 3u);
        if (auto *event_season_only = *reinterpret_cast<uintptr_t **>(GameOffsetFromTable("event_season_only")))
            XVarBool_Set(event_season_only, false, 3u);

        auto set_bool = [](uintptr_t *var, bool value) -> void {
            if (var)
                XVarBool_Set(var, value, 3u);
        };

        set_bool(&g_varDoubleRiftKeystones, global_config.events.DoubleRiftKeystones);
        set_bool(&g_varDoubleBloodShards, global_config.events.DoubleBloodShards);
        set_bool(&g_varDoubleTreasureGoblins, global_config.events.DoubleTreasureGoblins);
        set_bool(&g_varDoubleBountyBags, global_config.events.DoubleBountyBags);
        set_bool(&g_varRoyalGrandeur, global_config.events.RoyalGrandeur);
        set_bool(&g_varLegacyOfNightmares, global_config.events.LegacyOfNightmares);
        set_bool(&g_varTriunesWill, global_config.events.TriunesWill);
        set_bool(&g_varPandemonium, global_config.events.Pandemonium);
        set_bool(&g_varKanaiPowers, global_config.events.KanaiPowers);
        set_bool(&g_varTrialsOfTempests, global_config.events.TrialsOfTempests);
        set_bool(&g_varShadowClones, global_config.events.ShadowClones);
        set_bool(&g_varFourthKanaisCubeSlot, global_config.events.FourthKanaisCubeSlot);
        set_bool(&g_varEtherealItems, global_config.events.EtherealItems);
        set_bool(&g_varSoulShards, global_config.events.SoulShards);
        set_bool(&g_varSwarmRifts, global_config.events.SwarmRifts);
        set_bool(&g_varSanctifiedItems, global_config.events.SanctifiedItems);
        set_bool(&g_varDarkAlchemy, global_config.events.DarkAlchemy);
        set_bool(&g_varNestingPortals, global_config.events.NestingPortals);
        set_bool(&g_varParagonCap, false);  // ParagonCap off by default
    }

    static inline void PortCheatCodes() {
        if (!global_config.rare_cheats.active)
            return;
        auto jest = patch::RandomAccessPatcher();

        const auto &cheats = global_config.rare_cheats;
        /* Restore debug display of allocation errors */
        jest.Patch<ins::Movz>(PatchTable("patch_cheat_alloc_errors_01_movz"), reg::W8, 0);
        // jest.Patch<ins::MovRegister>(PatchTable("patch_cheat_alloc_errors_02_bytes"), reg::X0, SP);
        jest.Patch<dword>(PatchTable("patch_cheat_alloc_errors_02_bytes"), make_bytes(0xE0, 0x03, 0x00, 0x91));

        /* Spawn extra progress orbs */
        if (cheats.extra_gr_orbs_elites)
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_extra_gr_orbs_elites_01_movz"), reg::W3, 999);

        /* Drop any item (Staff of Herding, etc) */
        if (cheats.drop_anything)
            jest.Patch<ins::Movn>(PatchTable("patch_cheat_drop_anything_01_movn"), reg::W0, 0);
        // 04000000 00504C78 12800000

        /* 100% Legendary probability (Kadala/Kanai) */
        if (cheats.guaranteed_legendaries) {
            jest.Patch<ins::Nop>(PatchTable("patch_cheat_guaranteed_legendaries_01_nop"));  // unlikely? shot in the dark
            jest.Patch<ins::Nop>(PatchTable("patch_cheat_guaranteed_legendaries_02_nop"));
            jest.Patch<ins::Branch>(PatchTable("patch_cheat_guaranteed_legendaries_03_branch"), 0x18C);
            jest.Patch<ins::Nop>(PatchTable("patch_cheat_guaranteed_legendaries_04_nop"));
            jest.Patch<ins::Branch>(PatchTable("patch_cheat_guaranteed_legendaries_05_branch"), 0x350);
        }
        // jest.Patch<dword>(PatchTable("patch_cheat_guaranteed_legendaries_04_nop"), make_bytes(0xD4, 0x00, 0x00, 0x14));
        // 04000000 0088F9E0 140000D4

        /* Instant town portal & Book of Cain */
        if (cheats.instant_portal)
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_instant_portal_01_movz"), reg::W24, 0);
        // 04000000 009E3250 52800018

        /* Show testing art cosmetics */
        // jest.Patch<ins::CmnImmediate>(PatchTable("patch_cheat_testing_cosmetics_01_cmn_imm"), reg::W2, 0);
        // 04000000 004FFFE4 3100081F

        /* ►Primal ancient probability 100% */
        // jest.Patch<ins::Branch>(PatchTable("patch_cheat_primal_01_branch"), 0x360);
        // jest.Patch<ins::Movz>(PatchTable("patch_cheat_primal_02_movz"), reg::W8, 2);
        // jest.Patch<dword>(PatchTable("patch_cheat_primal_03_bytes"), make_bytes(0x40, 0x21, 0x2A, 0x1E));
        // jest.Patch<dword>(PatchTable("patch_cheat_primal_04_bytes"), make_bytes(0x00, 0x20, 0x20, 0x1E));  // covered by reg::W8, 2
        // jest.Patch<dword>(PatchTable("patch_cheat_primal_05_bytes"), make_bytes(0x1F, 0x20, 0x03, 0xD5));
        /*
        04000000 0088DF10 1E2A2140
        04000000 0088DFFC 1E202000
        04000000 0088DFE0 D503201F
        */

        /* ►No cooldown */
        if (cheats.no_cooldowns) {
            jest.Patch<dword>(PatchTable("patch_cheat_no_cooldowns_01_bytes"), make_bytes(0xE0, 0x03, 0x27, 0x1E));
            jest.Patch<dword>(PatchTable("patch_cheat_no_cooldowns_02_bytes"), make_bytes(0xE0, 0x03, 0x00, 0x2A));
            jest.Patch<dword>(PatchTable("patch_cheat_no_cooldowns_03_bytes"), make_bytes(0xE8, 0x03, 0x27, 0x1E));
            jest.Patch<dword>(PatchTable("patch_cheat_no_cooldowns_04_bytes"), make_bytes(0xE8, 0x03, 0x27, 0x1E));
        }
        /*
        04000000 007396D0 1E2703E0
        04000000 007F8960 2A0003E0
        04000000 009BC53C 1E2703E8
        04000000 009BC828 1E2703E8
        */

        /* ►Instantly identify items */
        if (cheats.instant_craft_actions)
            jest.Patch<ins::Nop>(PatchTable("patch_cheat_instant_identify_01_nop"));
        // 04000000 0020636C D503201F

        /* ►Instantly craft items */
        if (cheats.instant_craft_actions)
            jest.Patch<ins::AddImmediate>(PatchTable("patch_cheat_instant_craft_01_add_imm"), reg::W8, reg::W8, 5);
        // 04000000 0040F9B0 11001508

        /* ►Instantly enchant items */
        if (cheats.instant_craft_actions)
            jest.Patch<ins::AddImmediate>(PatchTable("patch_cheat_instant_enchant_01_add_imm"), reg::W8, reg::W8, 1);
        // 04000000 001DCFA4 11000508

        /* ►Instantly craft Kanai's Cube items */
        if (cheats.instant_craft_actions) {
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_cube_instant_craft_01_movz"), reg::W8, 0);
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_cube_instant_craft_02_movz"), reg::W9, 0);
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_cube_instant_craft_03_movz"), reg::W10, 0);
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_cube_instant_craft_04_movz"), reg::W8, 0);
        }
        /*
        04000000 00236D20 52800008
        04000000 00236D24 52800009
        04000000 00236D28 5280000A
        04000000 00236D30 52800008
        */

        /* ►Kanai's Cube does not consume materials */
        if (cheats.cube_no_consume)
            jest.Patch<ins::Ret>(PatchTable("patch_cheat_cube_no_consume_01_ret"));
        // 04000000 008874D0 D65F03C0

        /* ►Greater Rift Lv. 150 after clearing once */
        // jest.Patch<dword>(PatchTable("patch_cheat_gr150_01_bytes"), make_bytes(0xF5, 0x03, 0x00, 0x2A));
        // 04000000 004873E4 2A0003F5

        /* ►Legendary Gem Upgrade 100% */
        if (cheats.gem_upgrade_always)
            jest.Patch<dword>(PatchTable("patch_cheat_gem_upgrade_01_bytes"), make_bytes(0x08, 0x10, 0x2E, 0x1E));
        // 04000000 006A255C 1E2E1008*/

        /* ►Legendary Gem Upgrade Speed */
        if (cheats.gem_upgrade_speed)
            jest.Patch<dword>(PatchTable("patch_cheat_gem_speed_01_bytes"), make_bytes(0x02, 0x10, 0x2E, 0x1E));
        // 04000000 00349B98 1E2E1002

        /* ►Legendary Gem Lv. 150 after upgrading once */
        /*
        mov w22, w0
        movz w0, #0x96
        sub w23, w0, w22
        */
        // jest.Patch<ins::Movk>(PatchTable("patch_cheat_gem_lvl150_01_bytes"), reg::W22, reg::W0);  // MOV LIKE THIS?
        if (cheats.gem_upgrade_lvl150) {
            jest.Patch<dword>(PatchTable("patch_cheat_gem_lvl150_01_bytes"), make_bytes(0xF6, 0x03, 0x00, 0x2A));
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_gem_lvl150_02_movz"), reg::W0, 0x96);
            // jest.Patch<Sub>(PatchTable("patch_cheat_gem_lvl150_03_bytes"), reg::W23, reg::W0, reg::W22);
            jest.Patch<dword>(PatchTable("patch_cheat_gem_lvl150_03_bytes"), make_bytes(0x17, 0x00, 0x16, 0x4B));
            jest.Patch<ins::Ret>(PatchTable("patch_cheat_gem_lvl150_04_ret"));
            jest.Patch<dword>(PatchTable("patch_cheat_gem_lvl150_05_bytes"), make_bytes(0x89, 0x4D, 0x12, 0x94));
        }
        /*
        04000000 00C72F7C 2A0003F6
        04000000 00C72F80 528012C0
        04000000 00C72F84 4B160017
        04000000 00C72F88 D65F03C0
        04000000 007DF958 94124D89
        */

        // [►Equip Multiple Legendary Item]
        if (cheats.equip_multi_legendary)
            jest.Patch<ins::Branch>(PatchTable("patch_cheat_multi_legendary_01_branch"), 0x5C);
        // 04000000 004FB9E4 14000017

        // [►Socket Any Gem To Any Slot]
        if (cheats.any_gem_any_slot) {
            jest.Patch<ins::Movz>(PatchTable("patch_cheat_any_gem_any_slot_01_movz"), reg::W25, 5);
            jest.Patch<ins::Branch>(PatchTable("patch_cheat_any_gem_any_slot_02_branch"), 0xA0);
        }

        // [►Auto Pickup]
        if (cheats.auto_pickup)
            jest.Patch<ins::Nop>(PatchTable("patch_cheat_auto_pickup_01_nop"));
        // 04000000 004F98DC D503201F
    }

    void PatchInfiniteMp(const bool enabled) {
        auto jest = patch::RandomAccessPatcher();
        if (enabled) {
            jest.Patch<ins::Nop>(PatchTable("patch_infinite_mp_01_resource_bl"));
            return;
        }
        jest.Patch<dword>(PatchTable("patch_infinite_mp_01_resource_bl"), k_infinite_mp_restore_call);
    }

    void PatchBase() {
        auto jest = patch::RandomAccessPatcher();

        PortCheatCodes();

        XVarBool_Set(&g_varLocalLoggingEnable, true, 3u);
        XVarBool_Set(&g_varChallengeRiftEnabled, global_config.challenge_rifts.active, 3u);
        XVarBool_Set(&g_varSeasonsOverrideEnabled, global_config.seasons.active, 3u);
        XVarBool_Set(&g_varOnlineServicePTR, global_config.seasons.spoof_ptr, 3u);
        XVarBool_Set(&g_varExperimentalScheduling, global_config.resolution_hack.exp_scheduler, 3u);
        jest.Patch<ins::Movz>(PatchTable("patch_signin_01_movz"), reg::W0, 1);  // always Console::GamerProfile::IsSignedInOnline
        jest.Patch<ins::Ret>(PatchTable("patch_signin_02_ret"));                // ^ ret
        const bool infinite_mp = global_config.rare_cheats.active &&
                                 (global_config.rare_cheats.super_god_mode || global_config.rare_cheats.infinite_mp);
        PatchInfiniteMp(infinite_mp);

        /* String swap for autosave screen */
        MakeAdrlPatch(PatchTable("patch_autosave_string_01_adrl"), reinterpret_cast<uintptr_t>(g_szHackVerAutosave), reg::X0);

        /* String swap for start screen */
        MakeAdrlPatch(PatchTable("patch_start_string_01_adrl"), reinterpret_cast<uintptr_t>(&g_szHackVerStart), reg::X0);

        /* Enable local logging */
        jest.Patch<ins::Movz>(PatchTable("patch_local_logging_01_movz"), reg::W0, 1);

        // 0x00A2C614 - E5 0A 00 12
        // AND     reg::W5, reg::W23, #7
        // jest.Patch<exl::patch::inst::

        /* Pretend we are NOT in a mounted ROM */
        // jest.Patch<ins::Movz>(PatchTable("patch_rom_mount_01_movz"), reg::W1, 0);

        /* No timed wait for autosave warning */
        // jest.Patch<ins::Nop>(PatchTable("patch_autosave_wait_01_nop"));

        /* Inside ItemSetIsBeingManipulated(): BeingManipulated Attrib = 0 */
        // jest.Patch<ins::Branch>(PatchTable("patch_item_manipulated_01_branch"), 0x20);  // CBZ reg::W1, loc_BF090

        if (global_config.debug.enable_crashes) {
            /* Don't try to find a slot to equip newly duped item */
            jest.Patch<ins::Nop>(PatchTable("patch_dupe_noequip_01_nop"));  // BL ACDInventoryWhereCanThisGo()
            /* Stub functions that interfere with item duping */
            jest.Patch<ins::Ret>(PatchTable("patch_dupe_stub_01_ret")); /* void GameSoftPause(BOOL bPause) */
            jest.Patch<ins::Ret>(PatchTable("patch_dupe_stub_02_ret")); /* void ActorCommonData::SetAssignedHeroID(ActorCommonData *this, const Player *ptPlayer) */
            jest.Patch<ins::Ret>(PatchTable("patch_dupe_stub_03_ret")); /* void ActorCommonData::SetAssignedHeroID(ActorCommonData *this, OnlineService::HeroId idHero) */
            jest.Patch<ins::Ret>(PatchTable("patch_dupe_stub_04_ret")); /* void SGameSoftPause(BOOL bPause) */
        }

        /* Stub logging to RingBuffer */
        // jest.Patch<ins::Ret>(PatchTable("patch_log_ringbuffer_01_ret")); /* void FileOutputStream::LogToRingBuffer(int, char const*, char const*) */

        /* Stub net message tracing */
        // jest.Patch<ins::Ret>(PatchTable("patch_trace_message_01_ret")); /* void __fastcall sTraceMessage(const void *pMessage) */

        /* Fix path for stat tracing */
        MakeAdrlPatch(PatchTable("patch_trace_stat_path_01_adrl"), reinterpret_cast<uintptr_t>(&g_szTraceStat), reg::X0);

        if (!global_config.seasons.allow_online) {
            // Hide "Connect to Diablo Servers" menu entry (main menu item 12).
            // jest.Patch<ins::Branch>(PatchTable("patch_hideonline_01_branch"), -0x90);  // force false path in ItemShouldBeVisible

            /* Pause + Main menu: hide "Connect to Diablo Servers" list entry. */
            // 0x061620: STR reg::X19, [SP,#-0x10+var_10]!
            // 0x061624: STP reg::X29, reg::X30, [SP,#0x10+var_s0]
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_02_movz"), reg::W0, 0);  // return false
            jest.Patch<ins::Ret>(PatchTable("patch_hideonline_03_ret"));

            /* Main menu: hide Diablo Network status label in UIMainMenu::Console::OnUpdate. */
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_04_movz"), reg::W1, 0);  // off_1151298 visibility = 0 (connected path)
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_05_movz"), reg::W1, 0);  // off_1151290 visibility = 0 (disconnected path)
            // Hide the status text itself by calling SetVisible(0) on the text control instead of SetText.
            jest.Patch<dword>(PatchTable("patch_hideonline_06_bytes"), make_bytes(0x08, 0x29, 0x40, 0xF9));  // LDR reg::X8, [reg::X8,#0x50]
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_07_movz"), reg::W1, 0);

            /* Pause menu: hide Diablo Network status label in UIPause::Console::sOnWarningAccepted. */
            // 0x221324: MOV reg::W1, #1
            // 0x221338: MOV reg::W1, #1
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_08_movz"), reg::W1, 0);  // force SetVisible(0) for connected path
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_09_movz"), reg::W1, 0);  // force SetVisible(0) for disconnected path
            // Hide the status text itself by calling SetVisible(0) on the text control instead of SetText.
            jest.Patch<dword>(PatchTable("patch_hideonline_10_bytes"), make_bytes(0x08, 0x29, 0x40, 0xF9));  // LDR reg::X8, [reg::X8,#0x50]
            jest.Patch<ins::Movz>(PatchTable("patch_hideonline_11_movz"), reg::W1, 0);                       // reg::W1 = 0 (invisible)
        }

        /* Unlock all difficulties */
        // 0x5281B0: SXTW reg::X8, reg::W2
        // 0x5281B4: TBZ reg::W3, #0, loc_5281D8
        if (global_config.rare_cheats.active && global_config.rare_cheats.unlock_all_difficulties) {
            jest.Patch<ins::Movz>(PatchTable("patch_handicap_unlock_01_movz"), reg::W0, 1);  // return true
            jest.Patch<ins::Ret>(PatchTable("patch_handicap_unlock_02_ret"));
        }

        /* ItemCanDrop bypass */
        // jest.Patch<dword>(PatchTable("patch_itemcandrop_01_bytes"), make_bytes(0x10, 0x00, 0x00, 0x14));

        /* Increase the damage for ACTOR_EASYKILL_BIT */
        if (global_config.rare_cheats.active && global_config.rare_cheats.easy_kill_damage) {
            jest.Patch<ins::Movz>(PatchTable("patch_easykill_01_movz"), reg::W9, 0x7bc7);
            jest.Patch<ins::Movk>(PatchTable("patch_easykill_02_movk"), reg::W9, 0x5d94, ins::ShiftValue_16);
        }
        // 5863 5FA9 = 1,000 T
        // 5d94 7bc7 = 1,337,420T
        // 60e8 0dae = 133,769,696T
        // 6070 D958 = 69,420,000 T <--- lol
        // 6291 07B5 = 1,337,666,688 T
        // 61B6 53FF = 420,420,000 T
        // 61B6 6F61 = 420,666,656 T <--
        // 6210 8F6F = 666,666,688 T <--
    }

}  // namespace d3
